# StatWrapper
Provides an intermediate way of handling statistical data, separating it from the specific visualization implementation.   Currently the only supported visualization is JFreeChart.


Requires jfreechart and jcommon to build.  Any program that uses this library also requires those libraries.


Latest can always be located at:
https://github.com/ErebusMaligan/StatWrapper/releases/latest
