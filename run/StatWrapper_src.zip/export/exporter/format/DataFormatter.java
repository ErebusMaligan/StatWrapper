package export.exporter.format;

/**
 * @author Daniel J. Rivers
 *         2014
 *
 * Created: Jul 12, 2014, 9:40:18 PM 
 */
public interface DataFormatter {
	public Object format( Object value );	
}